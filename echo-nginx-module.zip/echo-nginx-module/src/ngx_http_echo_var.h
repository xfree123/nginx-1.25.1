#ifndef ECHO_VAR_H
#define ECHO_VAR_H

#include "ngx_http_echo_module.h"

ngx_int_t ngx_http_echo_add_variables(ngx_conf_t *cf);

#endif /* ECHO_VAR_H */

