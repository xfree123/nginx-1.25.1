/*---
includes: []
flags: []
paths: [test/js/module/]
negative:
  phase: runtime
---*/

import _ from 'recursive_early_access.js';
