/*---
includes: []
flags: []
paths: [test/js/module/]
---*/

import name from 'name.js';

assert.sameValue(name, "name");
